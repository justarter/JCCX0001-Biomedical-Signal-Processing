function [iterations, ranking] = Iteration_PR(G,error)
N = size(G, 1); % number of website
c = sum(G, 1);
ranking = [];
[~, index] = find(c > 0);
for i = index
    G(:, i) = G(:, i)./c(i);
end
iterations = 0;
PR0 = ones(N, 1);
PR =0.85* G * PR0+(1-0.85)/N*ones(N,1);
while norm(PR - PR0,2) > error
	PR0 = PR;
	PR =0.85* G * PR0+(1-0.85)/N*ones(N,1);
	iterations = iterations + 1;
    if iterations > 100000
        disp('10000 ���������޷��ﵽָ�������');
        return;
    end
end
message = [num2str(iterations), '����ﵽָ�������'];
disp(message);
ranking = sortrows([PR,(1:N)'], -1);
ranking = ranking(:,2);
end