load('wb-cs-stanford.mat')
Rank = zeros(20,3);
s1 = tic;
[iterations1, ranking1] = Power_PR(Problem.A',0.1);
t1 = toc(s1);
Rank(:,1) = ranking1(1:20);
s2 = tic;
[iterations2, ranking2] = Iteration_PR(Problem.A',0.1);
t2 = toc(s2);
Rank(:,2) = ranking2(1:20);
s3 = tic;
ranking3 = LinearPR(Problem.A');
t3 = toc(s3);
Rank(:,3) = ranking3(1:20);
